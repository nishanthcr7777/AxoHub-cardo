# Test Package

This is a sample package for testing AxoHub's publish functionality.

## Contents

- Sample smart contract code
- Documentation
- Examples

## Usage

```javascript
const contract = require('./contract.js');
contract.deploy();
```

## License

MIT
